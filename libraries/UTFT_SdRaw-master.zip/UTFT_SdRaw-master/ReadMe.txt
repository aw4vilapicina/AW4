Reorganised structure and added 'library.properties' file to conform to Library Spec V1.5.X

Added the ability to draw from Serial source. 

Just a SMALL update to remove the outdated #include <SdStream.h>

Also added a statistics file showing the speed increase in the ARM 800x480 example as a result of the latest SdFat version.

Thanks for downloading my UTFT_SdRaw library, please give me some 'Karma' on the forum if you appreciate my efforts.

Graham
